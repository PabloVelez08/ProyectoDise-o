package Snake;

import Copias.Snake22;
import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Food extends Thread{    
    Board board;
    ArrayList<Point> foods;
    static final Random r = new Random();
    int count=0;
    
    @Override
        public void run(){
            while(true){
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                
                checkFood();
                //checkBorder();
                //deleteSnakes();
                }
        }

        
        
        
        /*public void checkBorder(){
            if(snake.get(snake.size() - 1).x<15 || snake.get(snake.size() - 1).y<44
                    ||snake.get(snake.size() - 1).x>996||snake.get(snake.size() - 1).y>985){
                System.exit(0);
            }
        }*/

        
        /*public void showLocationHead(Point last){
            System.out.println(last.x +" | "+last.y);
        }*/
        
        
        
        public void checkFood(){
            if(foods.size() < 100){
                    foods.add(new Point(r.nextInt(900), r.nextInt(900))); //Randómico de coordenadas
                }
        }
        /*
        public void deleteFood(Point n){
            Iterator<Point> i = foods.iterator();
                while(i.hasNext()){
                    Point food = i.next();
                    if(food.distance(n) < 20){
                        i.remove();
                        count++;
                        size++;
                    }
                }
                board.repaint();
               // System.out.println("Puntaje por Comida "+count);
        }*/
        

    /*
    public ArrayList<Point> getEnemy() {
        return enemy;
    }

    public void setEnemy(ArrayList<Point> serpiente) {
        this.enemy = enemy;
        }
    }*/
}


