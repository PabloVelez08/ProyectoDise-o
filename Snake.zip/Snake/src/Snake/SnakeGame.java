package Snake;

public class SnakeGame {
    public static void main(String[] args) {
        Game c = new Game();
        c.startGame();
    }
}