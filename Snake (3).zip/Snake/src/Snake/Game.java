package Snake;



import Snake.Board;
import static Snake.Snake.r;
import java.awt.Color;
import java.awt.Image;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.util.ArrayList;
import java.util.Random;

public class Game {
    Board board;
    Snake snake; 
    Crash crash;
    Food food;
    Enemy enemy;

    public void startGame(){
        snake = new Snake();    
        board = new Board("Slither.io");
        crash = new Crash();
        food = new Food();
        enemy = new Enemy();

        board.snake = snake; 
        snake.board = board;
        
        board.food = food; 
        food.board = board;
        
        board.enemy = enemy;
        enemy.board = board;
        
        
        //point.snake = snake;
        //snake.snake = snake;
        
 
        
        snake.snake = new ArrayList<>();
        enemy.enemy = new ArrayList<>();
        food.foods = new ArrayList<>();
        
        snake.snake.add(new Point(500, 500));
        enemy.enemy.add(new Point(r.nextInt(900), r.nextInt(900)));

        snake.start();
        food.start();
        
        //finishGame();
    }
    
    public void getScore(){
        System.out.println("Puntaje por comida" + snake.count);
    }
    /*
    public void finishGame(){
        board.controlSize();
    }*/
    
}
