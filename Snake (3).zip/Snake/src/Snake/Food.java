package Snake;

import Copias.Snake22;
import java.awt.Color;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Food extends Thread{    
    Board board;
    ArrayList<Point> foods;
    static final Random r = new Random();
    int count=0;
    
    @Override
        public void run(){
            while(true){
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                generateFood();
                }
        }
        
        public void generateFood(){
            if(foods.size() < 100){
                    foods.add(new Point(r.nextInt(900), r.nextInt(900))); //Randómico de coordenadas
                }
        }
}


