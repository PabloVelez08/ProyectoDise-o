/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Snake;




public abstract class Entity extends Thread{
    Board board;
    Crash crash;
    int size=10;
    int speed = 10;
    public abstract void generate();
            /*public void move(ArrayList b,Point last, Point p, Point n){   
                if(last.distance(p) > 1){
                    n = calculateCoord(last, p);
                    b.add(n);
                    if(b.size() >= size){
                        for(int i = 0; i < b.size() - size; i++){
                            b.remove(i);
                        }
                    }
                  }
                board.repaint();
                eatFood(n);
        }
           
            
  public void eatFood(Point n){
            Iterator<Point> i = board.food.foods.iterator();
                while(i.hasNext()){
                    Point food = i.next();
                    if(food.distance(n) < 20){
                        i.remove();
                      //  count++;
                        size++;
                    }
                }
                board.repaint();
               // System.out.println("Puntaje por Comida "+count);
        }
  
  
          public Point calculateCoord(Point last, Point mouse){
            double degree = 0;
            if(last.x < mouse.x && last.y < mouse.y){
                degree = 360 - Math.toDegrees(Math.atan((double) (mouse.y - last.y) / (mouse.x - last.x)));
            }else if(last.x > mouse.x && last.y > mouse.y){
                degree = 180 - Math.toDegrees(Math.atan((double) (last.y - mouse.y) / (last.x - mouse.x)));
            }else if(last.y > mouse.y && last.x < mouse.x){
                degree = Math.toDegrees(Math.atan((double) (last.y - mouse.y) / (mouse.x - last.x)));
            }else if(last.y < mouse.y && last.x > mouse.x){
                degree = 180 + Math.toDegrees(Math.atan((double) (mouse.y - last.y) / (last.x - mouse.x)));
            }
            Point p = new Point((int) 
                    (last.x + Math.cos(Math.toRadians(degree)) * speed), (int) 
                    (last.y - Math.sin(Math.toRadians(degree)) * speed));
            return p;
        }*/
}
